﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StackoverflowApplication.Models
{
    public class markings
    {
        public int mID { get; set; }
        public int postID { get; set; }
        public bool status { get; set; }
    }
}

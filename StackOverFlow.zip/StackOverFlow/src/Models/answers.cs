﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StackoverflowApplication.Models
{
    public class answers
    {
        public int postID { get; set; }
        public int parentID { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StackoverflowApplication.Models
{
    public class users
    {
        public int userID { get; set; }
        public string userName { get; set; }
        public string userLocation { get; set; }
        public int userAge { get; set; }
        public DateTime userCreationDate { get; set; }
    }
}

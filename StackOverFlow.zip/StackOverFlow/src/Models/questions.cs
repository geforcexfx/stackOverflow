﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StackoverflowApplication.Models
{
    public class questions
    {
        public int postID { get; set; }
        public DateTime closedDate { get; set; }
        public string title { get; set; }
    }
}

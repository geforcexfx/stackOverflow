﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StackoverflowApplication.Models
{
    public class linkposts
    {
        public int pID { get; set; }
        public int linkPostID { get; set; }
        public int postID { get; set; }
    }
}

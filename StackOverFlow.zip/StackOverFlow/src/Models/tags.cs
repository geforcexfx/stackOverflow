﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StackoverflowApplication.Models
{
    public class tags
    {
        public int postID { get; set; }
        public string tag { get; set; }
    }
}

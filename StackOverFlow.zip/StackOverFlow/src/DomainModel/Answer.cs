﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DomainModel
{
    public class Answer
    {
        public int PostID { get; set; }
        public int parentID { get; set; }
    }
}
